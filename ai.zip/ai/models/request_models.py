"""
models/request_models.py
Pydantic v2 models for incoming API requests.
"""

from __future__ import annotations

from typing import Optional, Union
from pydantic import BaseModel, Field, field_validator


# ──────────────────────────────────────────────────────────────
# Transcript item when supplied as a structured array
# ──────────────────────────────────────────────────────────────
class TranscriptItem(BaseModel):
    """A single timestamped segment from a structured transcript array."""

    start_time: str = Field(..., description="Segment start in HH:MM:SS.mmm or MM:SS.mmm format")
    end_time: str = Field(..., description="Segment end in HH:MM:SS.mmm or MM:SS.mmm format")
    text: str = Field(..., description="Spoken content for this segment")


# ──────────────────────────────────────────────────────────────
# Main request model
# ──────────────────────────────────────────────────────────────
class TranscriptRequest(BaseModel):
    """
    POST /analyze-transcript request body.

    `transcript` accepts either:
      - A plain timestamped string  (e.g. "00:00:01.000 - 00:00:05.000 | Hello world")
      - A structured JSON array     (list of TranscriptItem dicts)
    """

    transcript: Union[str, list[TranscriptItem]] = Field(
        ...,
        description="Raw timestamped transcript as a string or structured array of segments.",
    )

    video_title: Optional[str] = Field(
        default=None,
        max_length=200,
        description="Optional video title for context.",
    )

    target_duration_seconds: Optional[int] = Field(
        default=None,
        ge=10,
        le=3600,
        description="Target final edited duration in seconds (optional).",
    )

    style_preset: str = Field(
        default="viral_short",
        description=(
            "Editorial personality preset. "
            "Choices: viral_short | documentary | podcast | tutorial"
        ),
    )

    @field_validator("style_preset")
    @classmethod
    def validate_preset(cls, v: str) -> str:
        allowed = {"viral_short", "documentary", "podcast", "tutorial"}
        if v.lower() not in allowed:
            raise ValueError(f"style_preset must be one of: {', '.join(sorted(allowed))}")
        return v.lower()

    @field_validator("transcript")
    @classmethod
    def validate_transcript_not_empty(cls, v: Union[str, list]) -> Union[str, list]:
        if isinstance(v, str) and not v.strip():
            raise ValueError("transcript string must not be empty.")
        if isinstance(v, list) and len(v) == 0:
            raise ValueError("transcript array must contain at least one segment.")
        return v
