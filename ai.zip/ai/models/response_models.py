"""
models/response_models.py
Pydantic v2 models for the complete multi-layer JSON editing timeline response.
These models mirror the JSON schema defined in prompts/director_prompt.txt exactly.
"""

from __future__ import annotations

from typing import Literal, Optional
from pydantic import BaseModel, Field


# ──────────────────────────────────────────────────────────────
# Meta summary layer
# ──────────────────────────────────────────────────────────────
class ViralShortClip(BaseModel):
    clip_id: int
    start_time: str
    end_time: str
    hook_description: str


class MetaSummary(BaseModel):
    total_raw_duration: str
    projected_final_duration: str
    estimated_retention_score: Literal["HIGH", "MEDIUM", "LOW"]
    recommended_viral_shorts: list[ViralShortClip] = Field(default_factory=list)


# ──────────────────────────────────────────────────────────────
# Video layer
# ──────────────────────────────────────────────────────────────
FramingEffect = Literal["NORMAL", "SMART_ZOOM_IN", "ZOOM_OUT", "GLITCH_PULSE"]
TransitionOut = Literal["NONE", "FAST_GLITCH", "CROSS_BLUR", "JUMP_CUT"]


class VideoLayer(BaseModel):
    framing_effect: FramingEffect = "NORMAL"
    transition_out: TransitionOut = "NONE"


# ──────────────────────────────────────────────────────────────
# Audio layer
# ──────────────────────────────────────────────────────────────
BgMusicEnergy = Literal["LOW", "MEDIUM", "HIGH"]
SfxTrigger = Literal["NONE", "SWOOSH", "RISER", "DING", "POP"]


class AudioLayer(BaseModel):
    audio_ducking: bool = False
    bg_music_energy: BgMusicEnergy = "MEDIUM"
    sfx_trigger: SfxTrigger = "NONE"


# ──────────────────────────────────────────────────────────────
# Text overlay
# ──────────────────────────────────────────────────────────────
TextStyle = Literal["STANDARD", "DYNAMIC_POP_UP", "NEON_GLOW"]


class TextOverlay(BaseModel):
    word: str
    exact_timestamp: str
    style: TextStyle = "STANDARD"


# ──────────────────────────────────────────────────────────────
# Timeline segment (one per input segment)
# ──────────────────────────────────────────────────────────────
Action = Literal["KEEP", "CUT"]
PerformanceType = Literal[
    "HOOK",
    "INTELLECTUAL_EXPLANATION",
    "CHILL_PACING",
    "STUMBLE",
    "REPEAT_TAKE",
    "SILENCE",
]


class TimelineSegment(BaseModel):
    segment_id: int
    start_time: str
    end_time: str
    action: Action
    performance_type: PerformanceType
    intellectual_peak: bool = False
    transcript_segment: str
    video_layer: VideoLayer
    audio_layer: AudioLayer
    text_overlays: list[TextOverlay] = Field(default_factory=list)


# ──────────────────────────────────────────────────────────────
# Top-level response
# ──────────────────────────────────────────────────────────────
class EditingTimeline(BaseModel):
    """
    The complete production-ready multi-layer JSON editing timeline.
    This is the root model returned by POST /analyze-transcript.
    """

    meta_summary: MetaSummary
    timeline_tracks: list[TimelineSegment]
