"""
services/transcript_parser.py
Normalises a raw transcript (string or structured array) into a canonical
plain-text representation ready to be injected into the GPT-4o prompt.
"""

from __future__ import annotations

import re
from typing import Union

from models.request_models import TranscriptItem


# ──────────────────────────────────────────────────────────────
# Internal helpers
# ──────────────────────────────────────────────────────────────

def _normalize_timestamp(ts: str) -> str:
    """
    Ensure a timestamp is in HH:MM:SS.mmm format.
    Accepts MM:SS.mmm, MM:SS, HH:MM:SS, HH:MM:SS.mmm
    """
    ts = ts.strip()
    # Already in HH:MM:SS.mmm
    if re.match(r"^\d{2}:\d{2}:\d{2}\.\d{3}$", ts):
        return ts
    # HH:MM:SS (no millis)
    if re.match(r"^\d{2}:\d{2}:\d{2}$", ts):
        return f"{ts}.000"
    # MM:SS.mmm
    m = re.match(r"^(\d{1,2}):(\d{2})\.(\d{1,3})$", ts)
    if m:
        mm, ss, ms = m.group(1).zfill(2), m.group(2), m.group(3).ljust(3, "0")
        return f"00:{mm}:{ss}.{ms}"
    # MM:SS
    m = re.match(r"^(\d{1,2}):(\d{2})$", ts)
    if m:
        mm, ss = m.group(1).zfill(2), m.group(2)
        return f"00:{mm}:{ss}.000"
    # Return as-is and let the downstream caller handle any issues
    return ts


def _parse_raw_string(raw: str) -> str:
    """
    Parse a free-form timestamped string and return a consistently formatted version.

    Supported line formats (all common export styles are handled):
      00:00:01.000 - 00:00:05.500 | Hello world
      [00:00:01.000] Hello world
      00:00:01,000 --> 00:00:05,500\nHello world   (SRT / WebVTT style)
      00:00:01 Hello world
    """
    # Normalise SRT comma milliseconds → dot
    raw = raw.replace(",", ".")

    lines = raw.strip().splitlines()
    output_lines: list[str] = []

    for line in lines:
        line = line.strip()
        if not line:
            continue

        # Skip pure numeric SRT index lines
        if re.match(r"^\d+$", line):
            continue

        # SRT/WebVTT arrow style:  00:00:01.000 --> 00:00:05.500
        m = re.match(
            r"(\d{1,2}:\d{2}:\d{2}\.\d{3})\s*-->\s*(\d{1,2}:\d{2}:\d{2}\.\d{3})",
            line,
        )
        if m:
            # Next line(s) contain the text; we'll concat them below — skip for now
            output_lines.append(f"{_normalize_timestamp(m.group(1))} - {_normalize_timestamp(m.group(2))} |")
            continue

        # Pipe delimiter: 00:00:01.000 - 00:00:05.000 | text
        m = re.match(
            r"(\d{1,2}:\d{2}[:\d.]*)\s*[-–]\s*(\d{1,2}:\d{2}[:\d.]*)\s*[|:]\s*(.+)",
            line,
        )
        if m:
            start = _normalize_timestamp(m.group(1))
            end = _normalize_timestamp(m.group(2))
            text = m.group(3).strip()
            output_lines.append(f"{start} - {end} | {text}")
            continue

        # Bracket style: [00:00:01.000] text
        m = re.match(r"\[(\d{1,2}:\d{2}[:\d.]*)\]\s*(.+)", line)
        if m:
            ts = _normalize_timestamp(m.group(1))
            text = m.group(2).strip()
            output_lines.append(f"{ts} | {text}")
            continue

        # Bare timestamp + text: 00:00:01 Hello
        m = re.match(r"(\d{1,2}:\d{2}[:\d.]*)\s+(.+)", line)
        if m:
            ts = _normalize_timestamp(m.group(1))
            text = m.group(2).strip()
            output_lines.append(f"{ts} | {text}")
            continue

        # Plain text line (no timestamp) — append to previous line's text if exists
        if output_lines:
            output_lines[-1] = output_lines[-1] + " " + line
        else:
            output_lines.append(line)

    return "\n".join(output_lines)


def _structured_to_string(items: list[TranscriptItem]) -> str:
    """Convert a structured TranscriptItem array to canonical string format."""
    lines: list[str] = []
    for item in items:
        start = _normalize_timestamp(item.start_time)
        end = _normalize_timestamp(item.end_time)
        lines.append(f"{start} - {end} | {item.text.strip()}")
    return "\n".join(lines)


# ──────────────────────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────────────────────

def parse_transcript(transcript: Union[str, list[TranscriptItem]]) -> str:
    """
    Accepts either a raw timestamped string or a list of TranscriptItems.
    Returns a single, consistently formatted string ready for GPT-4o injection.

    Raises:
        ValueError: If the transcript cannot be parsed into any recognisable format.
    """
    if isinstance(transcript, list):
        result = _structured_to_string(transcript)
    else:
        result = _parse_raw_string(transcript)

    if not result.strip():
        raise ValueError(
            "Transcript could not be parsed — ensure it contains valid timestamped lines."
        )

    return result
