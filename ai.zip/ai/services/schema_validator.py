"""
services/schema_validator.py
Validates GPT-4o raw JSON output against the editing timeline schema.
Returns a parsed EditingTimeline or raises a structured error.
"""

from __future__ import annotations

import json
import logging

from pydantic import ValidationError

from models.response_models import EditingTimeline

logger = logging.getLogger(__name__)


class SchemaValidationError(Exception):
    """Raised when GPT-4o output does not match the required schema."""

    def __init__(self, message: str, raw_output: str, validation_errors: list[dict] | None = None):
        super().__init__(message)
        self.raw_output = raw_output
        self.validation_errors = validation_errors or []


def validate_timeline(raw_json_str: str) -> EditingTimeline:
    """
    Validate the GPT-4o raw response string against the EditingTimeline schema.

    Args:
        raw_json_str: The raw JSON string returned by GPT-4o.

    Returns:
        A validated EditingTimeline Pydantic model instance.

    Raises:
        SchemaValidationError: If the JSON is malformed or doesn't match the schema.
    """
    # Step 1 — Parse raw JSON
    try:
        data = json.loads(raw_json_str)
    except json.JSONDecodeError as exc:
        logger.error("GPT-4o returned invalid JSON: %s", exc)
        raise SchemaValidationError(
            f"GPT-4o response is not valid JSON: {exc}",
            raw_output=raw_json_str,
        ) from exc

    # Step 2 — Validate against Pydantic schema
    try:
        timeline = EditingTimeline.model_validate(data)
    except ValidationError as exc:
        errors = exc.errors(include_url=False)
        logger.error("Schema validation failed with %d error(s): %s", len(errors), errors)
        raise SchemaValidationError(
            f"GPT-4o response failed schema validation with {len(errors)} error(s).",
            raw_output=raw_json_str,
            validation_errors=errors,
        ) from exc

    # Step 3 — Sanity checks
    _run_sanity_checks(timeline)

    return timeline


def _run_sanity_checks(timeline: EditingTimeline) -> None:
    """
    Run lightweight logical consistency checks on the parsed timeline.
    Logs warnings for violations instead of hard-failing, to be lenient with GPT outputs.
    """
    segments = timeline.timeline_tracks

    if not segments:
        logger.warning("GPT-4o returned a timeline with 0 segments.")
        return

    # Check segment IDs are sequential
    ids = [s.segment_id for s in segments]
    expected_ids = list(range(1, len(segments) + 1))
    if ids != expected_ids:
        logger.warning(
            "Segment IDs are not sequential. Got: %s", ids[:10]
        )

    # Check for intellectual_peak consistency
    for seg in segments:
        if seg.action == "CUT" and seg.intellectual_peak:
            logger.warning(
                "Segment %d is marked CUT but intellectual_peak=True — unusual.", seg.segment_id
            )
        if seg.action == "CUT" and seg.text_overlays:
            logger.warning(
                "Segment %d is marked CUT but has %d text_overlays — these will be ignored.",
                seg.segment_id,
                len(seg.text_overlays),
            )

    keep_count = sum(1 for s in segments if s.action == "KEEP")
    cut_count = len(segments) - keep_count
    logger.info(
        "Timeline validated: %d total segments — %d KEEP, %d CUT",
        len(segments),
        keep_count,
        cut_count,
    )
