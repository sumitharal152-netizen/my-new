"""
services/gpt_engine.py
GPT-4o integration layer.
Builds the full prompt, calls the OpenAI API, and returns the raw JSON string.
"""

from __future__ import annotations

import logging
import time
from pathlib import Path

import openai
from openai import OpenAI

from config import get_settings

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────
# Load the master system prompt once at import time
# ──────────────────────────────────────────────────────────────
_PROMPT_PATH = Path(__file__).parent.parent / "prompts" / "director_prompt.txt"

try:
    _SYSTEM_PROMPT: str = _PROMPT_PATH.read_text(encoding="utf-8")
except FileNotFoundError as exc:
    raise RuntimeError(
        f"Director system prompt not found at {_PROMPT_PATH}. "
        "Ensure prompts/director_prompt.txt exists."
    ) from exc


# ──────────────────────────────────────────────────────────────
# OpenAI client (lazy singleton)
# ──────────────────────────────────────────────────────────────
_client: OpenAI | None = None


def _get_client() -> OpenAI:
    global _client
    if _client is None:
        settings = get_settings()
        _client = OpenAI(api_key=settings.openai_api_key)
    return _client


# ──────────────────────────────────────────────────────────────
# Prompt builder
# ──────────────────────────────────────────────────────────────

def _build_user_message(
    normalized_transcript: str,
    video_title: str | None,
    target_duration_seconds: int | None,
    style_preset: str,
) -> str:
    """Construct the user-turn message injected alongside the system prompt."""
    parts: list[str] = []

    if video_title:
        parts.append(f"VIDEO TITLE: {video_title}")

    parts.append(f"STYLE PRESET: {style_preset.upper()}")

    if target_duration_seconds:
        m, s = divmod(target_duration_seconds, 60)
        parts.append(f"TARGET FINAL DURATION: {m:02d}:{s:02d}")

    parts.append("\n─────────────────────────────────────────────────────")
    parts.append("TIMESTAMPED TRANSCRIPT:")
    parts.append("─────────────────────────────────────────────────────")
    parts.append(normalized_transcript)
    parts.append("─────────────────────────────────────────────────────")
    parts.append(
        "\nAnalyze the above transcript and return ONLY the complete JSON editing timeline. "
        "No markdown, no commentary, no code fences."
    )

    return "\n".join(parts)


# ──────────────────────────────────────────────────────────────
# Main engine call (with retry on rate limit)
# ──────────────────────────────────────────────────────────────

def analyze_transcript(
    normalized_transcript: str,
    video_title: str | None = None,
    target_duration_seconds: int | None = None,
    style_preset: str = "viral_short",
    max_retries: int = 3,
    retry_delay_seconds: float = 5.0,
) -> str:
    """
    Send the transcript to GPT-4o and return the raw JSON response string.

    Args:
        normalized_transcript: Pre-processed canonical transcript string.
        video_title: Optional title for editorial context.
        target_duration_seconds: Optional target final edit duration.
        style_preset: Editorial personality (viral_short | documentary | podcast | tutorial).
        max_retries: Number of retry attempts on rate-limit or timeout errors.
        retry_delay_seconds: Initial delay between retries (doubles on each attempt).

    Returns:
        Raw JSON string from GPT-4o.

    Raises:
        openai.OpenAIError: On unrecoverable API errors.
        RuntimeError: If all retries are exhausted.
    """
    settings = get_settings()

    # Guard: fail fast with a clear message if the API key is missing
    if not settings.openai_api_key:
        raise RuntimeError(
            "OPENAI_API_KEY is not set. "
            "Copy .env.example → .env and add your OpenAI API key, then restart the server."
        )

    client = _get_client()

    user_message = _build_user_message(
        normalized_transcript=normalized_transcript,
        video_title=video_title,
        target_duration_seconds=target_duration_seconds,
        style_preset=style_preset,
    )

    last_error: Exception | None = None
    delay = retry_delay_seconds

    for attempt in range(1, max_retries + 1):
        try:
            logger.info(
                "GPT-4o call attempt %d/%d | model=%s | preset=%s",
                attempt,
                max_retries,
                settings.openai_model,
                style_preset,
            )

            response = client.chat.completions.create(
                model=settings.openai_model,
                response_format={"type": "json_object"},  # Guaranteed JSON output
                temperature=settings.openai_temperature,
                max_tokens=settings.openai_max_tokens,
                messages=[
                    {"role": "system", "content": _SYSTEM_PROMPT},
                    {"role": "user", "content": user_message},
                ],
            )

            raw_json = response.choices[0].message.content
            if not raw_json:
                raise RuntimeError("GPT-4o returned an empty response.")

            finish_reason = response.choices[0].finish_reason
            if finish_reason == "length":
                logger.warning(
                    "GPT-4o hit max_tokens limit (finish_reason=length). "
                    "Consider increasing OPENAI_MAX_TOKENS or shortening the transcript."
                )

            logger.info(
                "GPT-4o response received — %d chars | finish_reason=%s | "
                "tokens used: prompt=%d, completion=%d",
                len(raw_json),
                finish_reason,
                response.usage.prompt_tokens if response.usage else -1,
                response.usage.completion_tokens if response.usage else -1,
            )

            return raw_json

        except openai.RateLimitError as exc:
            last_error = exc
            logger.warning(
                "Rate limit hit on attempt %d. Retrying in %.1fs...", attempt, delay
            )
            time.sleep(delay)
            delay *= 2  # Exponential back-off

        except openai.APITimeoutError as exc:
            last_error = exc
            logger.warning(
                "API timeout on attempt %d. Retrying in %.1fs...", attempt, delay
            )
            time.sleep(delay)
            delay *= 2

        except openai.OpenAIError as exc:
            # Non-retryable errors — fail fast
            logger.error("Unrecoverable OpenAI API error: %s", exc)
            raise

    raise RuntimeError(
        f"All {max_retries} GPT-4o call attempts failed. Last error: {last_error}"
    )
