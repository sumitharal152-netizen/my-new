@echo off
REM ─────────────────────────────────────────────
REM  AI Video Director Engine — Start Script
REM  Usage: start.bat
REM ─────────────────────────────────────────────

echo [*] Activating virtual environment...
call .venv\Scripts\activate.bat

echo [*] Checking for .env file...
if not exist .env (
    echo [!] WARNING: .env file not found.
    echo [!] Copy .env.example to .env and set your OPENAI_API_KEY first.
    pause
    exit /b 1
)

echo [*] Starting AI Video Director Engine...
echo [*] Swagger UI: http://localhost:8001/docs
echo [*] Press CTRL+C to stop.
echo.

python -m uvicorn main:app --reload --host 0.0.0.0 --port 8001
