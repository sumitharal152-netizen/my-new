"""
main.py — AI Video Director Engine
FastAPI application entrypoint.

Run with:
    uvicorn main:app --reload --host 0.0.0.0 --port 8000

Swagger UI:
    http://localhost:8000/docs

ReDoc:
    http://localhost:8000/redoc
"""

from __future__ import annotations

import logging
import time
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from config import Settings, get_settings
from routers.analyze import router as analyze_router

# ──────────────────────────────────────────────────────────────
# Logging setup
# ──────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────
# Lifespan (startup / shutdown events)
# ──────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    logger.info("=" * 60)
    logger.info("  🎬 AI Video Director Engine — STARTING UP")
    logger.info("  Model      : %s", settings.openai_model)
    logger.info("  Max tokens : %d", settings.openai_max_tokens)
    logger.info("  Temperature: %.2f", settings.openai_temperature)
    logger.info("  CORS       : %s", settings.allowed_origins)
    logger.info("=" * 60)
    yield
    logger.info("🎬 AI Video Director Engine — SHUT DOWN")


# ──────────────────────────────────────────────────────────────
# App initialisation
# ──────────────────────────────────────────────────────────────
app = FastAPI(
    title="AI Video Director Engine",
    description=(
        "🎬 **Production-ready automated video editing timeline generator** powered by GPT-4o.\n\n"
        "Analyzes timestamped transcripts and generates complete multi-layer JSON editing timelines "
        "with jump-cut decisions, smart zoom keyframes, caption callouts, audio design, and "
        "viral short-clip detection.\n\n"
        "### Quick Start\n"
        "1. Copy `.env.example` → `.env` and set your `OPENAI_API_KEY`\n"
        "2. Install: `pip install -r requirements.txt`\n"
        "3. Run: `uvicorn main:app --reload`\n"
        "4. POST to `/analyze-transcript` with your timestamped transcript"
    ),
    version="1.0.0",
    contact={
        "name": "AI Video Director Engine",
    },
    license_info={
        "name": "MIT",
    },
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# ──────────────────────────────────────────────────────────────
# Middleware
# ──────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def request_timing_middleware(request: Request, call_next):
    """Log request timing for every API call."""
    start = time.perf_counter()
    response = await call_next(request)
    elapsed_ms = (time.perf_counter() - start) * 1000
    logger.info(
        "%s %s → %d [%.0fms]",
        request.method,
        request.url.path,
        response.status_code,
        elapsed_ms,
    )
    response.headers["X-Process-Time-Ms"] = f"{elapsed_ms:.0f}"
    return response


# ──────────────────────────────────────────────────────────────
# Routes
# ──────────────────────────────────────────────────────────────
app.include_router(analyze_router)


@app.get("/", tags=["Health"], summary="Root health check")
async def root(settings: Settings = Depends(get_settings)):
    """Returns basic service info and confirms the engine is online."""
    return {
        "service": "AI Video Director Engine",
        "version": "1.0.0",
        "status": "online",
        "model": settings.openai_model,
        "api_key_configured": bool(settings.openai_api_key),
        "endpoints": {
            "analyze": "POST /analyze-transcript",
            "docs": "GET /docs",
            "redoc": "GET /redoc",
        },
    }


@app.get("/health", tags=["Health"], summary="Health check")
async def health():
    """Lightweight health probe for load balancers / uptime monitors."""
    return {"status": "ok"}


# ──────────────────────────────────────────────────────────────
# Global exception handler (catch-all safety net)
# ──────────────────────────────────────────────────────────────
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.exception("Unhandled exception on %s %s: %s", request.method, request.url.path, exc)
    return JSONResponse(
        status_code=500,
        content={
            "error": "internal_server_error",
            "message": "An unexpected error occurred. Check server logs for details.",
        },
    )


# ──────────────────────────────────────────────────────────────
# Dev entry point
# ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    _s = get_settings()
    uvicorn.run(
        "main:app",
        host=_s.host,
        port=_s.port,
        reload=True,
        log_level="info",
    )
