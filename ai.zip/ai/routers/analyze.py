"""
routers/analyze.py
POST /analyze-transcript — the core endpoint of the AI Video Director Engine.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse

from models.request_models import TranscriptRequest
from models.response_models import EditingTimeline
from services.gpt_engine import analyze_transcript
from services.schema_validator import SchemaValidationError, validate_timeline
from services.transcript_parser import parse_transcript

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/analyze-transcript", tags=["Video Director Engine"])


# ──────────────────────────────────────────────────────────────
# POST /analyze-transcript
# ──────────────────────────────────────────────────────────────

@router.post(
    "",
    response_model=EditingTimeline,
    summary="Analyze a timestamped transcript and generate a multi-layer editing timeline",
    response_description=(
        "A complete production-ready JSON editing timeline with jump-cut decisions, "
        "smart zoom keyframes, caption callouts, audio design, and viral clip windows."
    ),
    responses={
        200: {
            "description": "Successfully generated editing timeline",
        },
        422: {
            "description": "Invalid or unparseable transcript input",
        },
        500: {
            "description": "GPT-4o API error or schema validation failure",
        },
        504: {
            "description": "OpenAI API timeout — transcript may be too long",
        },
    },
)
async def analyze(request_body: TranscriptRequest) -> Any:
    """
    ## AI Video Director Engine

    Analyzes a raw timestamped transcript and returns a **complete, production-ready,
    multi-layer JSON editing timeline** powered by GPT-4o.

    ### What gets generated:
    - **Jump-cut decisions** (KEEP / CUT) with performance classification
    - **Smart zoom keyframes** (SMART_ZOOM_IN / ZOOM_OUT / GLITCH_PULSE)
    - **Transition effects** (FAST_GLITCH / CROSS_BLUR / JUMP_CUT)
    - **Caption & text callout overlays** (DYNAMIC_POP_UP / NEON_GLOW)
    - **Audio ducking + SFX triggers** (SWOOSH / RISER / DING / POP)
    - **Viral short-clip windows** (30–60 second standalone reels)

    ### Transcript format (string):
    ```
    00:00:01.000 - 00:00:05.000 | Welcome everyone to today's session
    00:00:05.200 - 00:00:09.800 | Today we're going to talk about AI strategy
    ```
    Also accepts SRT, WebVTT, bracket timestamps, or a structured JSON array.
    """

    # ── Step 1: Parse & normalise transcript ─────────────────────────────────
    try:
        normalized = parse_transcript(request_body.transcript)
    except ValueError as exc:
        logger.warning("Transcript parse failed: %s", exc)
        raise HTTPException(
            status_code=422,
            detail={
                "error": "transcript_parse_error",
                "message": str(exc),
            },
        )

    logger.info(
        "Transcript parsed successfully | %d chars | preset=%s | title=%s",
        len(normalized),
        request_body.style_preset,
        request_body.video_title or "untitled",
    )

    # ── Step 2: Call GPT-4o ──────────────────────────────────────────────────
    try:
        raw_json = analyze_transcript(
            normalized_transcript=normalized,
            video_title=request_body.video_title,
            target_duration_seconds=request_body.target_duration_seconds,
            style_preset=request_body.style_preset,
        )
    except RuntimeError as exc:
        logger.error("GPT engine error: %s", exc)
        raise HTTPException(
            status_code=500,
            detail={
                "error": "gpt_engine_error",
                "message": str(exc),
            },
        )
    except Exception as exc:
        # Map common OpenAI errors to HTTP codes
        exc_name = type(exc).__name__
        if "Timeout" in exc_name:
            raise HTTPException(
                status_code=504,
                detail={
                    "error": "openai_timeout",
                    "message": "OpenAI API timed out. Try shortening your transcript or retry.",
                },
            )
        logger.exception("Unexpected error during GPT-4o call: %s", exc)
        raise HTTPException(
            status_code=500,
            detail={
                "error": "unexpected_error",
                "message": str(exc),
            },
        )

    # ── Step 3: Validate schema ──────────────────────────────────────────────
    try:
        timeline = validate_timeline(raw_json)
    except SchemaValidationError as exc:
        logger.error("Schema validation failed: %s | validation_errors=%s", exc, exc.validation_errors)
        raise HTTPException(
            status_code=500,
            detail={
                "error": "schema_validation_error",
                "message": str(exc),
                "validation_errors": exc.validation_errors[:10],  # cap to avoid giant payloads
                "raw_gpt_output_preview": exc.raw_output[:500],
            },
        )

    logger.info(
        "Timeline generated successfully | segments=%d | viral_shorts=%d",
        len(timeline.timeline_tracks),
        len(timeline.meta_summary.recommended_viral_shorts),
    )

    return timeline
